﻿using System;

namespace calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            menu vMenu = new menu();
            vMenu.open();
        }
    }
}
