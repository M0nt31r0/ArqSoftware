﻿using System;

namespace Aula06_ex01
{
    class Program
    {
        static void Main(string[] args)
        {
            menu vMenu = new menu();
            vMenu.open();
        }
    }
}
